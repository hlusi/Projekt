# Pure Python AES realisation (with CLI)
### Available commands
##### Generate key file (by default creates 128-bit key)
```shell script
$ python main.py generate test.key
```
###### Using key size option
```shell script
$ python main.py generate -s 128 test.128.key
$ python main.py generate -s 192 test.192.key
$ python main.py generate -s 256 test.256.key
$ wc -c test.*.key
        16 test.128.key
        24 test.192.key
        32 test.256.key
        72 total
```
##### Encrypt file
```shell script
$ md5 test.file
MD5 (test.file) = 13a943bcb5a61cd5b8ecd3163dce1191
$ python main.py encrypt test.file test.key
$ md5 test.file
MD5 (test.file) = 5b44db80ee253a0f881ec0c5dc9ab9d5
```
##### Decrypt file
```shell script
$ md5 test.file
MD5 (test.file) = 5b44db80ee253a0f881ec0c5dc9ab9d5
$ python main.py decrypt test.file test.key
$ md5 test.file
MD5 (test.file) = 13a943bcb5a61cd5b8ecd3163dce1191
```
### Used materials
  * [AES on Wikipedia][0]
  * [FIPS PUB 197][1]

[0]: https://en.wikipedia.org/wiki/Advanced_Encryption_Standard
[1]: https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.197.pdf
